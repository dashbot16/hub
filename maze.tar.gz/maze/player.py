import pygame
import random

# Player class to control the player's movement and state
class Player:
    def __init__(self, maze, tile_size):
        self.maze = maze
        self.tile_size = tile_size
        self.x, self.y = self.get_random_open_tile()  # Random open tile in maze
        self.color = (0, 0, 255)  # Blue color
        self.speed = 150  # Pixels per second, adjust as needed

    def get_random_open_tile(self):
        # Randomly choose an open tile (represented by 0 in the maze)
        open_tiles = [(x, y) for y in range(len(self.maze)) for x in range(len(self.maze[y])) if self.maze[y][x] == 0]
        return random.choice(open_tiles)

    def handle_movement(self, keys, delta_time):
        move_x, move_y = 0, 0

        # Check for key presses (WASD keys)
        if keys[pygame.K_w]:  # Up
            move_y = -1
        if keys[pygame.K_s]:  # Down
            move_y = 1
        if keys[pygame.K_a]:  # Left
            move_x = -1
        if keys[pygame.K_d]:  # Right
            move_x = 1

        # Normalize movement speed and apply delta_time for smooth movement
        move_x *= self.speed * delta_time
        move_y *= self.speed * delta_time

        # Update player position based on movement
        self.x += move_x
        self.y += move_y

        # Keep the player within the maze boundaries
        self.x = max(0, min(self.x, (len(self.maze[0]) - 1) * self.tile_size))
        self.y = max(0, min(self.y, (len(self.maze) - 1) * self.tile_size))

    def update_position(self, delta_time):
        # This function allows the enemy to smoothly chase the player
        pass

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.tile_size, self.tile_size))

