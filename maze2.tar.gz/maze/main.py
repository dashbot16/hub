import pygame
import sys
from player import Player  # Import the Player class

# Initialize pygame
pygame.init()

# Set up screen dimensions and colors
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 40
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (169, 169, 169)
BLUE = (0, 0, 255)

# Create the screen object
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Maze Game")

# Function to read the maze from a text file
def load_maze(filename="maze.txt"):
    with open(filename, 'r') as f:
        # Read the maze and convert it into a 2D list (list of lists)
        maze = [list(map(int, line.strip())) for line in f.readlines()]
    return maze

# Function to draw the maze
def draw_maze(maze):
    for y in range(len(maze)):
        for x in range(len(maze[y])):
            tile = maze[y][x]
            color = WHITE if tile == 0 else BLACK  # White for empty, Black for wall
            pygame.draw.rect(screen, color, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))

# Main game loop
def main():
    running = True
    clock = pygame.time.Clock()

    # Load the maze from the file
    maze = load_maze("maze.txt")

    # Instantiate the player
    player = Player(maze, TILE_SIZE)

    while running:
        delta_time = clock.tick(60) / 1000.0  # Get the delta time for smooth movement (in seconds)

        screen.fill(BLUE)  # Background color

        draw_maze(maze)
        player.update_position(delta_time)  # Smooth player movement
        player.draw(screen)  # Draw the player

        # Event handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Handle player movement
        keys = pygame.key.get_pressed()
        player.handle_movement(keys, delta_time)  # Handle smooth movement based on key presses

        pygame.display.flip()

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()

