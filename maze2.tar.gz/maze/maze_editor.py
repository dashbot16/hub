import pygame
import sys

# Initialize pygame
pygame.init()

# Set up screen dimensions and colors
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
TILE_SIZE = 40
GRID_WIDTH = SCREEN_WIDTH // TILE_SIZE
GRID_HEIGHT = SCREEN_HEIGHT // TILE_SIZE
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (169, 169, 169)
BLUE = (0, 0, 255)

# Create the screen object
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Simple Level Editor")

# Define tile map (0 = empty, 1 = wall)
tile_map = [[0 for _ in range(GRID_WIDTH)] for _ in range(GRID_HEIGHT)]

# Function to draw the grid and the tiles
def draw_grid():
    for y in range(GRID_HEIGHT):
        for x in range(GRID_WIDTH):
            tile = tile_map[y][x]
            color = WHITE if tile == 0 else BLACK  # White for empty, Black for wall
            pygame.draw.rect(screen, color, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE))
            pygame.draw.rect(screen, GREY, (x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE), 1)  # Grid lines

# Function to handle mouse click on the grid
def handle_mouse_click():
    mouse_x, mouse_y = pygame.mouse.get_pos()
    grid_x = mouse_x // TILE_SIZE
    grid_y = mouse_y // TILE_SIZE

    # Toggle between empty (0) and wall (1) for left-click
    if pygame.mouse.get_pressed()[0]:  # Left click to place walls
        tile_map[grid_y][grid_x] = 1
    # Erase tile with right-click
    elif pygame.mouse.get_pressed()[2]:  # Right click to clear tile
        tile_map[grid_y][grid_x] = 0

# Save the maze to a file
def save_maze(filename="maze.txt"):
    with open(filename, 'w') as f:
        for row in tile_map:
            f.write("".join(str(cell) for cell in row) + "\n")
    print(f"Maze saved to {filename}")

# Main game loop
running = True
while running:
    screen.fill(BLUE)  # Background color

    draw_grid()

    # Event handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1 or event.button == 3:  # Left or Right click
                handle_mouse_click()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_s:  # Press 'S' to save the maze
                save_maze()

    pygame.display.flip()

pygame.quit()
sys.exit()

