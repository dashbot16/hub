import pygame
import random
import math
import sys

# Initialize Pygame
pygame.init()

# Game settings
WIDTH, HEIGHT = 1280, 720
FPS = 60
PLAYER_SPEED = 300
BULLET_SPEED = 600
ENEMY_SPEED = 100
PLAYER_HEALTH = 5
ENEMY_HEALTH = 3
INVINCIBILITY_DURATION = 1.0  # seconds
KNOCKBACK_STRENGTH = 150
WAVE_SIZE_INCREMENT = 2
FLASH_DURATION = 0.1  # seconds

# Colors
WHITE = (255, 255, 255)
RED = (200, 50, 50)
GREEN = (50, 200, 50)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
BLUE = (50, 150, 255)
DARK_BLUE = (10, 30, 60)

# Setup screen
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.HWSURFACE | pygame.DOUBLEBUF)
pygame.display.set_caption("spacegame")
clock = pygame.time.Clock()
BG = pygame.image.load("shoot-em-up/Background_Full-0001.png").convert()
BG = pygame.transform.scale(BG, (WIDTH, HEIGHT))
crosshair_img = pygame.image.load("kenney_crosshairPack/PNG/White/crosshair027.png").convert_alpha()
icon = pygame.image.load("anime.png")
pygame.display.set_icon(icon) 

# Font for text display
font = pygame.font.Font('press-start-2p/PressStart2P.ttf', 12)
font2 = pygame.font.Font('Neoblock-DEMO.otf', 24)
game_over_font = pygame.font.Font('Neoblock-DEMO.otf', 72)
pause_font = pygame.font.Font('Neoblock-DEMO.otf', 48)
menu_font = pygame.font.Font('Neoblock-DEMO.otf', 48)

# Start Menu Flag
in_menu = True

# Particle class
class Particle:
    def __init__(self, pos):
        self.pos = pygame.Vector2(pos)
        self.velocity = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1)) * 100
        self.lifetime = random.uniform(0.3, 0.6)
        self.radius = random.randint(2, 4)

    def update(self, dt):
        self.lifetime -= dt
        self.pos += self.velocity * dt

    def draw(self, surface):
        if self.lifetime > 0:
            pygame.draw.circle(surface, RED, (int(self.pos.x), int(self.pos.y)), self.radius)

# Screen shake
shake_timer = 0
shake_magnitude = 0

# Flash effect
flash_timer = 0.0

# Kill count and record
kill_count = 0
record = 0

try:
    with open("record.txt", "r") as f:
        record = int(f.read())
except:
    record = 0

def trigger_screen_shake(magnitude, duration):
    global shake_timer, shake_magnitude
    shake_timer = duration
    shake_magnitude = magnitude

def apply_screen_shake():
    if shake_timer > 0:
        return pygame.Vector2(random.randint(-shake_magnitude, shake_magnitude), random.randint(-shake_magnitude, shake_magnitude))
    return pygame.Vector2(0, 0)

# Player class
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load('player.png').convert_alpha()
        self.image = pygame.image.load('player.png').convert_alpha()
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.speed = PLAYER_SPEED
        self.health = PLAYER_HEALTH
        self.last_hit_time = -INVINCIBILITY_DURATION
        self.velocity = pygame.Vector2(0, 0)
        self.mx = None
        self.my = None

    def update(self, keys, dt):
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt
        self.velocity *= 0.9

        dx, dy = 0, 0
        if keys[pygame.K_w]: dy = -1
        if keys[pygame.K_s]: dy = 1
        if keys[pygame.K_a]: dx = -1
        if keys[pygame.K_d]: dx = 1

        movement = pygame.Vector2(dx, dy)
        if movement.length() > 0:
            movement = movement.normalize()

        self.rect.x += movement.x * self.speed * dt
        self.rect.y += movement.y * self.speed * dt
        self.rect.clamp_ip(screen.get_rect())

        self.mx, self.my = pygame.mouse.get_pos()
        angle = math.degrees(math.atan2(self.rect.centery - self.my, self.mx - self.rect.centerx)) - 90
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def take_damage(self, current_time, source_pos):
        global flash_timer
        if current_time - self.last_hit_time >= INVINCIBILITY_DURATION:
            self.health -= 1
            self.last_hit_time = current_time
            flash_timer = FLASH_DURATION
            knockback = pygame.Vector2(self.rect.center) - pygame.Vector2(source_pos)
            if knockback.length() > 0:
                knockback = knockback.normalize() * KNOCKBACK_STRENGTH
                self.velocity += knockback
            trigger_screen_shake(5, 0.2)
            if self.health <= 0:
                return True
        return False

# Bullet class
class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.original_image = pygame.image.load('bullet.png').convert_alpha()
        self.velocity = pygame.Vector2(direction).normalize() * BULLET_SPEED
        angle = math.degrees(math.atan2(-self.velocity.y, self.velocity.x)) - 90
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=pos)

    def update(self, dt):
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt
        if not screen.get_rect().colliderect(self.rect):
            self.kill()

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load('enemy1.png').convert_alpha()
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect(center=(random.randint(0, WIDTH), random.randint(0, HEIGHT)))
        self.health = ENEMY_HEALTH
        self.flash_timer = 0  # <- add this

    def update(self, player_pos, dt):
        direction = pygame.Vector2(player_pos) - pygame.Vector2(self.rect.center)
        if direction.length() > 0:
            direction = direction.normalize()
        self.rect.x += direction.x * ENEMY_SPEED * dt
        self.rect.y += direction.y * ENEMY_SPEED * dt

        # Update flash timer
        if self.flash_timer > 0:
            self.flash_timer -= dt
            if self.flash_timer <= 0:
                self.image = self.original_image.copy()  # reset after flash

    def draw_health_bar(self, surface):
        health_ratio = self.health / ENEMY_HEALTH
        bar_width = self.rect.width
        bar_height = 5
        bar_x = self.rect.left
        bar_y = self.rect.top - bar_height - 4
        pygame.draw.rect(surface, GRAY, (bar_x, bar_y, bar_width, bar_height))
        pygame.draw.rect(surface, GREEN, (bar_x, bar_y, bar_width * health_ratio, bar_height))

    def flash_red(self):
        flash_surface = self.original_image.copy()
        flash_surface.fill((255, 0, 0), special_flags=pygame.BLEND_ADD)
        self.image = flash_surface
        self.flash_timer = 0.1  # flash for 0.1 seconds


# Sprite groups
player = Player()
bullets = pygame.sprite.Group()
enemies = pygame.sprite.Group()
all_sprites = pygame.sprite.Group(player)
particles = []

# Events
SPAWNENEMY = pygame.USEREVENT + 1
pygame.time.set_timer(SPAWNENEMY, 1000)

def draw_player_health_bar(surface, player):
    max_width = 275
    bar_height = 8
    health_ratio = player.health / PLAYER_HEALTH
    bar_width = int(max_width * health_ratio)
    x = WIDTH // 2 - max_width // 2
    y = 20
    pygame.draw.rect(surface, DARK_BLUE, (x - 2, y - 2, max_width + 4, bar_height + 4))
    pygame.draw.rect(surface, BLUE, (x, y, bar_width, bar_height))

# Game loop
running = True
game_over = False
paused = False
wave = 1
total_enemies = 5
spawned_enemies = 0

def spawn_wave(wave_size):
    global spawned_enemies
    for _ in range(wave_size):
        enemy = Enemy()
        enemies.add(enemy)
        all_sprites.add(enemy)
    spawned_enemies += wave_size

spawn_wave(total_enemies)

# Reset Game Function
def reset_game():
    global game_over, paused, wave, total_enemies, spawned_enemies, kill_count
    global player, bullets, enemies, all_sprites, particles

    game_over = False
    paused = False
    wave = 1
    total_enemies = 5
    spawned_enemies = 0
    kill_count = 0

    player = Player()
    bullets.empty()
    enemies.empty()
    all_sprites.empty()
    all_sprites.add(player)
    particles.clear()

    spawn_wave(total_enemies)

while running:
    dt = clock.tick(FPS) / 1000.0
    keys = pygame.key.get_pressed()
    current_time = pygame.time.get_ticks() / 1000.0
    pygame.mouse.set_visible(False)

    # MENU
    if in_menu:
        screen.fill(BLACK)
        title_text = menu_font.render("SPACEGAME", True, WHITE)
        prompt_text = font2.render("Press any key to start", True, GRAY)
        screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))
        screen.blit(prompt_text, (WIDTH // 2 - prompt_text.get_width() // 2, HEIGHT // 2))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                in_menu = False
        continue

    # IN GAME
    if shake_timer > 0:
        shake_timer -= dt

    if flash_timer > 0:
        flash_timer -= dt
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            paused = not paused
            if paused == True: print("PAUSED") 
            else: print("PLAYING")
        if not game_over and not paused:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                direction = (mx - player.rect.centerx, my - player.rect.centery)
                bullet = Bullet(player.rect.center, direction)
                bullets.add(bullet)
                all_sprites.add(bullet)
    
    if game_over or paused:
        keys = pygame.key.get_pressed()
        if keys[pygame.K_r]:
            # Reset game state
            if kill_count > record:
                    with open("record.txt", "w") as f:
                        f.write(str(kill_count))
                        record = kill_count
            reset_game()
            print(record)
        if keys[pygame.K_m]:
            # Reset game state
            pygame.quit()
            sys.exit()

    if not game_over and not paused:
        player.update(keys, dt)
        bullets.update(dt)
        for enemy in enemies:
            enemy.update(player.rect.center, dt)

        for bullet in bullets:
            hit_list = pygame.sprite.spritecollide(bullet, enemies, False)
            for enemy in hit_list:
                enemy.health -= 1
                enemy.flash_red()
                bullet.kill()
                particles.extend([Particle(enemy.rect.center) for _ in range(5)])
                trigger_screen_shake(3, 0.1)
                if enemy.health <= 0:
                    enemy.kill()
                    kill_count += 1
                

        player_hit_list = pygame.sprite.spritecollide(player, enemies, False)
        for enemy in player_hit_list:
            if player.take_damage(current_time, enemy.rect.center):
                game_over = True
                if kill_count > record:
                    with open("record.txt", "w") as f:
                        f.write(str(kill_count))

        if len(enemies) == 0:
            wave += 1
            total_enemies += WAVE_SIZE_INCREMENT
            spawn_wave(total_enemies)

    for p in particles[:]:
        p.update(dt)
        if p.lifetime <= 0:
            particles.remove(p)

    # Drawing
    screen.blit(BG, (0, 0))
    crosshair_rect = crosshair_img.get_rect(center=(player.mx, player.my))
    screen.blit(crosshair_img, crosshair_rect)
    offset = apply_screen_shake()
    temp_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

    all_sprites.draw(temp_surface)
    for enemy in enemies:
        enemy.draw_health_bar(temp_surface)
    for p in particles:
        p.draw(temp_surface)

    draw_player_health_bar(temp_surface, player)

    fps = int(clock.get_fps())
    kill_count = int(kill_count)

    fps_text = font.render("FPS: " + str(fps), True, WHITE)
    kill_text = font.render("Kills: " + str(kill_count), True, WHITE)
    record_text = font.render("Record: " + str(record), True, WHITE)
    wave_text = font.render("Wave: " + str(wave), True, WHITE)

    temp_surface.blit(fps_text, (10, 10))
    temp_surface.blit(kill_text, (10, 30))
    temp_surface.blit(record_text, (10, 50))
    temp_surface.blit(wave_text, (10, 70))

    if game_over:
        over_text = game_over_font.render("GAME OVER", True, RED)
        temp_surface.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 2 - over_text.get_height() // 2))
        restart_text = font.render("Press R to Restart", True, (255, 255, 255))
        temp_surface.blit(restart_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT - 70))
        quit_text = font.render("Press M to Quit", True, (255, 255, 255))
        temp_surface.blit(quit_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT - 40))

    if paused and not game_over:
        pause_text = pause_font.render("PAUSED", True, WHITE)
        temp_surface.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2 - pause_text.get_height() // 2))
        restart_text = font.render("Press R to Restart", True, (255, 255, 255))
        temp_surface.blit(restart_text, (WIDTH // 2 - pause_text.get_width() // 1, HEIGHT - 70))
        quit_text = font.render("Press M to Quit", True, (255, 255, 255))
        temp_surface.blit(quit_text, (WIDTH // 2 - pause_text.get_width() // 1, HEIGHT - 40 ))
        

    screen.blit(temp_surface, offset)

    if flash_timer > 0:
        flash_overlay = pygame.Surface((WIDTH, HEIGHT))
        flash_overlay.fill(WHITE)
        flash_overlay.set_alpha(150)
        screen.blit(flash_overlay, (0, 0))

    pygame.display.flip()

pygame.quit()
sys.exit()

