import pygame
import sys

pygame.init()
screen = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Text Display Test")
clock = pygame.time.Clock()

font = pygame.font.Font('press-start-2p/PressStart2P.ttf', 36)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

kill_count = 5
record = 10

print(pygame.font.get_fonts())


while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    screen.fill(BLACK)

    fps = int(clock.get_fps())
    fps_text = font.render(f"FPS: {fps}", True, WHITE)
    kill_text = font.render(f"Kills: {kill_count}", True, WHITE)
    record_text = font.render(f"Record: {record}", True, WHITE)

    screen.blit(fps_text, (10, 10))
    screen.blit(kill_text, (10, 50))
    screen.blit(record_text, (10, 90))

    pygame.display.flip()
    clock.tick(60)

