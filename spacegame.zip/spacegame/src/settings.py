# src/settings.py

# General Settings
WIDTH, HEIGHT = 1280, 720
FPS = 60

# Player Settings
PLAYER_SPEED = 300
PLAYER_HEALTH = 5
INVINCIBILITY_DURATION = 1.0
KNOCKBACK_STRENGTH = 150

# Bullet Settings
BULLET_SPEED = 600

# Enemy Settings
ENEMY_SPEED = 100
ENEMY_HEALTH = 3
WAVE_SIZE_INCREMENT = 2

# Particle Settings
FLASH_DURATION = 0.1

# Screen Shake
SHAKE_DURATION = 0.2
SHAKE_MAGNITUDE = 5

# Colors
WHITE = (255, 255, 255)
RED = (200, 50, 50)
GREEN = (50, 200, 50)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
BLUE = (50, 150, 255)
DARK_BLUE = (10, 30, 60)

# Asset Paths
PLAYER_IMAGE = "../assets/images/player.png"
BULLET_IMAGE = "../assets/images/bullet.png"
ENEMY_IMAGE = "../assets/images/enemy1.png"
BACKGROUND_IMAGE = "../assets/images/background.png"
CROSSHAIR_IMAGE = "../assets/images/crosshair.png"
ICON_IMAGE = "../assets/images/anime.png"

# Fonts
FONT_MAIN = "../assets/fonts/PressStart2P.ttf"
FONT_TITLE = "../assets/fonts/Neoblock-DEMO.otf"
