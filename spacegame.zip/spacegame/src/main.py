# src/main.py

import pygame, sys, os
from settings import *
from player import Player
from enemy import Enemy
from bullet import Bullet
from particle import Particle
from utils import trigger_screen_shake, apply_screen_shake
from ui import *
from pygame.math import Vector2

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.HWSURFACE | pygame.DOUBLEBUF)
pygame.display.set_caption("Spacegame")
pygame.display.set_icon(pygame.image.load(ICON_IMAGE))
clock = pygame.time.Clock()

# Load assets
BG = pygame.transform.scale(pygame.image.load(BACKGROUND_IMAGE).convert(), (WIDTH, HEIGHT))
crosshair_img = pygame.image.load(CROSSHAIR_IMAGE).convert_alpha()
font = pygame.font.Font(FONT_MAIN, 12)
font2 = pygame.font.Font(FONT_TITLE, 24)
font_big = pygame.font.Font(FONT_TITLE, 72)
pause_font = pygame.font.Font(FONT_TITLE, 48)

# State vars
in_menu = True
paused = False
game_over = False
wave = 1
total_enemies = 5
kill_count = 0

# Record
record_file = "data/record.txt"
record = 0
if os.path.exists(record_file):
    with open(record_file, "r") as f:
        record = int(f.read())

# Groups & Entities
player = Player()
bullets = pygame.sprite.Group()
enemies = pygame.sprite.Group()
all_sprites = pygame.sprite.Group(player)
particles = []

def spawn_wave(n):
    for _ in range(n):
        e = Enemy()
        enemies.add(e)
        all_sprites.add(e)

def reset_game():
    global player, bullets, enemies, all_sprites, particles
    global game_over, paused, wave, total_enemies, kill_count

    player = Player()
    bullets.empty()
    enemies.empty()
    all_sprites.empty()
    all_sprites.add(player)
    particles.clear()

    game_over = False
    paused = False
    wave = 1
    total_enemies = 5
    kill_count = 0
    spawn_wave(total_enemies)

spawn_wave(total_enemies)

# Flash effect
flash_timer = 0.0

# === GAME LOOP ===
running = True
while running:
    dt = clock.tick(FPS) / 1000.0
    current_time = pygame.time.get_ticks() / 1000.0
    keys = pygame.key.get_pressed()
    pygame.mouse.set_visible(False)

    # Menu loop
    if in_menu:
        draw_menu(screen, pause_font, font2)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT: pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN or event.type == pygame.MOUSEBUTTONDOWN:
                in_menu = False
        continue

    # Event Handling
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if not game_over and not paused:
            if event.type == pygame.MOUSEBUTTONDOWN:
                mx, my = pygame.mouse.get_pos()
                direction = (mx - player.rect.centerx, my - player.rect.centery)
                bullet = Bullet(player.rect.center, direction)
                bullets.add(bullet)
                all_sprites.add(bullet)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                paused = not paused
            if event.key == pygame.K_r:
                if kill_count > record:
                    with open(record_file, "w") as f:
                        f.write(str(kill_count))
                reset_game()
            if event.key == pygame.K_m:
                pygame.quit()
                sys.exit()

    if not paused and not game_over:
        player.update(keys, dt)
        bullets.update(dt)
        for enemy in enemies:
            enemy.update(player.rect.center, dt)

        for bullet in bullets:
            hits = pygame.sprite.spritecollide(bullet, enemies, False)
            for enemy in hits:
                enemy.health -= 1
                enemy.flash_red()
                bullet.kill()
                particles.extend([Particle(enemy.rect.center) for _ in range(5)])
                trigger_screen_shake(3, 0.1)
                if enemy.health <= 0:
                    enemy.kill()
                    kill_count += 1

        hits = pygame.sprite.spritecollide(player, enemies, False)
        for enemy in hits:
            if player.take_damage(current_time, enemy.rect.center):
                game_over = True
                if kill_count > record:
                    with open(record_file, "w") as f:
                        f.write(str(kill_count))

        if len(enemies) == 0:
            wave += 1
            total_enemies += WAVE_SIZE_INCREMENT
            spawn_wave(total_enemies)

        for p in particles[:]:
            p.update(dt)
            if p.lifetime <= 0:
                particles.remove(p)

    # Drawing
    offset = apply_screen_shake(dt)
    screen.blit(BG, (0, 0))
    temp_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
    all_sprites.draw(temp_surface)
    for enemy in enemies:
        enemy.draw_health_bar(temp_surface)
    for p in particles:
        p.draw(temp_surface)

    draw_player_health_bar(temp_surface, player)
    draw_hud(temp_surface, font, kill_count, record, wave, clock.get_fps())
    draw_crosshair(temp_surface, crosshair_img, player.mx, player.my)

    if game_over:
        draw_game_over(temp_surface, font_big, font)
    elif paused:
        draw_pause_menu(temp_surface, pause_font, font)

    screen.blit(temp_surface, offset)

    if flash_timer > 0:
        flash_timer -= dt
        flash_overlay = pygame.Surface((WIDTH, HEIGHT))
        flash_overlay.fill(WHITE)
        flash_overlay.set_alpha(150)
        screen.blit(flash_overlay, (0, 0))

    pygame.display.flip()

pygame.quit()
sys.exit()
