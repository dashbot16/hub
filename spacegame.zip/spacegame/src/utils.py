# src/utils.py

import pygame
import random
from settings import SHAKE_MAGNITUDE

shake_timer = 0
shake_strength = 0

def load_image(path, scale=None):
    img = pygame.image.load(path).convert_alpha()
    if scale:
        img = pygame.transform.scale(img, scale)
    return img

def trigger_screen_shake(magnitude, duration):
    global shake_timer, shake_strength
    shake_timer = duration
    shake_strength = magnitude

def apply_screen_shake(dt):
    global shake_timer
    if shake_timer > 0:
        shake_timer -= dt
        offset = pygame.Vector2(
            random.randint(-shake_strength, shake_strength),
            random.randint(-shake_strength, shake_strength)
        )
        return offset
    return pygame.Vector2(0, 0)

def clamp_rect_to_screen(rect, screen_rect):
    if rect.left < screen_rect.left:
        rect.left = screen_rect.left
    if rect.right > screen_rect.right:
        rect.right = screen_rect.right
    if rect.top < screen_rect.top:
        rect.top = screen_rect.top
    if rect.bottom > screen_rect.bottom:
        rect.bottom = screen_rect.bottom
    return rect
