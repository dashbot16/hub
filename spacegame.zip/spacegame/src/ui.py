# src/ui.py

import pygame
from settings import *
from pygame.math import Vector2

def draw_player_health_bar(surface, player):
    max_width = 275
    bar_height = 8
    health_ratio = player.health / PLAYER_HEALTH
    bar_width = int(max_width * health_ratio)
    x = WIDTH // 2 - max_width // 2
    y = 20

    pygame.draw.rect(surface, DARK_BLUE, (x - 2, y - 2, max_width + 4, bar_height + 4))
    pygame.draw.rect(surface, BLUE, (x, y, bar_width, bar_height))

def draw_hud(surface, font, kill_count, record, wave, fps):
    fps_text = font.render(f"FPS: {int(fps)}", True, WHITE)
    kill_text = font.render(f"Kills: {kill_count}", True, WHITE)
    record_text = font.render(f"Record: {record}", True, WHITE)
    wave_text = font.render(f"Wave: {wave}", True, WHITE)

    surface.blit(fps_text, (10, 10))
    surface.blit(kill_text, (10, 30))
    surface.blit(record_text, (10, 50))
    surface.blit(wave_text, (10, 70))

def draw_crosshair(surface, crosshair_img, mx, my):
    crosshair_rect = crosshair_img.get_rect(center=(mx, my))
    surface.blit(crosshair_img, crosshair_rect)

def draw_game_over(surface, font_large, font_small):
    over_text = font_large.render("GAME OVER", True, RED)
    surface.blit(over_text, (WIDTH // 2 - over_text.get_width() // 2, HEIGHT // 2 - over_text.get_height() // 2))

    restart_text = font_small.render("Press R to Restart", True, WHITE)
    surface.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT - 70))

    quit_text = font_small.render("Press M to Quit", True, WHITE)
    surface.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT - 40))

def draw_pause_menu(surface, font, font_small):
    pause_text = font.render("PAUSED", True, WHITE)
    surface.blit(pause_text, (WIDTH // 2 - pause_text.get_width() // 2, HEIGHT // 2 - pause_text.get_height() // 2))

    restart_text = font_small.render("Press R to Restart", True, WHITE)
    surface.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT - 70))

    quit_text = font_small.render("Press M to Quit", True, WHITE)
    surface.blit(quit_text, (WIDTH // 2 - quit_text.get_width() // 2, HEIGHT - 40))

def draw_menu(surface, font_large, font_small):
    surface.fill(BLACK)
    title_text = font_large.render("SPACEGAME", True, WHITE)
    prompt_text = font_small.render("Press any key to start", True, GRAY)
    surface.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))
    surface.blit(prompt_text, (WIDTH // 2 - prompt_text.get_width() // 2, HEIGHT // 2))
