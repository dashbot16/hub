# src/enemy.py

import pygame
import random
from settings import ENEMY_IMAGE, ENEMY_HEALTH, ENEMY_SPEED, GRAY, GREEN
from pygame.math import Vector2

class Enemy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load(ENEMY_IMAGE).convert_alpha()
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect(center=(random.randint(0, 1280), random.randint(0, 720)))
        self.health = ENEMY_HEALTH
        self.flash_timer = 0

    def update(self, player_pos, dt):
        direction = Vector2(player_pos) - Vector2(self.rect.center)
        if direction.length() > 0:
            direction = direction.normalize()
        self.rect.x += direction.x * ENEMY_SPEED * dt
        self.rect.y += direction.y * ENEMY_SPEED * dt

        if self.flash_timer > 0:
            self.flash_timer -= dt
            if self.flash_timer <= 0:
                self.image = self.original_image.copy()

    def flash_red(self):
        flash_surface = self.original_image.copy()
        flash_surface.fill((255, 0, 0), special_flags=pygame.BLEND_ADD)
        self.image = flash_surface
        self.flash_timer = 0.1

    def draw_health_bar(self, surface):
        health_ratio = self.health / ENEMY_HEALTH
        bar_width = self.rect.width
        bar_height = 5
        bar_x = self.rect.left
        bar_y = self.rect.top - bar_height - 4
        pygame.draw.rect(surface, GRAY, (bar_x, bar_y, bar_width, bar_height))
        pygame.draw.rect(surface, GREEN, (bar_x, bar_y, bar_width * health_ratio, bar_height))
