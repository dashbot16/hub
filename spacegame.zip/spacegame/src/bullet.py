# src/bullet.py

import pygame
import math
from settings import BULLET_IMAGE, BULLET_SPEED
from pygame.math import Vector2

class Bullet(pygame.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.original_image = pygame.image.load(BULLET_IMAGE).convert_alpha()
        self.velocity = Vector2(direction).normalize() * BULLET_SPEED
        angle = math.degrees(math.atan2(-self.velocity.y, self.velocity.x)) - 90
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=pos)

    def update(self, dt):
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt
        if not pygame.Rect(0, 0, 1280, 720).colliderect(self.rect):
            self.kill()
