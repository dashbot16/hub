# src/player.py

import pygame
import math
from settings import *
from utils import trigger_screen_shake
from pygame.math import Vector2

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.original_image = pygame.image.load(PLAYER_IMAGE).convert_alpha()
        self.image = self.original_image.copy()
        self.rect = self.image.get_rect(center=(WIDTH // 2, HEIGHT // 2))
        self.speed = PLAYER_SPEED
        self.health = PLAYER_HEALTH
        self.last_hit_time = -INVINCIBILITY_DURATION
        self.velocity = Vector2(0, 0)
        self.mx = None
        self.my = None

    def update(self, keys, dt):
        self.rect.x += self.velocity.x * dt
        self.rect.y += self.velocity.y * dt
        self.velocity *= 0.9

        dx, dy = 0, 0
        if keys[pygame.K_w]: dy = -1
        if keys[pygame.K_s]: dy = 1
        if keys[pygame.K_a]: dx = -1
        if keys[pygame.K_d]: dx = 1

        movement = Vector2(dx, dy)
        if movement.length() > 0:
            movement = movement.normalize()

        self.rect.x += movement.x * self.speed * dt
        self.rect.y += movement.y * self.speed * dt
        self.rect.clamp_ip(pygame.Rect(0, 0, WIDTH, HEIGHT))

        self.mx, self.my = pygame.mouse.get_pos()
        angle = math.degrees(math.atan2(self.rect.centery - self.my, self.mx - self.rect.centerx)) - 90
        self.image = pygame.transform.rotate(self.original_image, angle)
        self.rect = self.image.get_rect(center=self.rect.center)

    def take_damage(self, current_time, source_pos):
        if current_time - self.last_hit_time >= INVINCIBILITY_DURATION:
            self.health -= 1
            self.last_hit_time = current_time
            knockback = Vector2(self.rect.center) - Vector2(source_pos)
            if knockback.length() > 0:
                knockback = knockback.normalize() * KNOCKBACK_STRENGTH
                self.velocity += knockback
            trigger_screen_shake(SHAKE_MAGNITUDE, SHAKE_DURATION)
            return self.health <= 0
        return False
