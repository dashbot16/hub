# src/particle.py

import pygame
import random
from settings import RED

class Particle:
    def __init__(self, pos, color=RED, speed=100, lifetime_range=(0.3, 0.6), radius_range=(2, 4)):
        self.pos = pygame.Vector2(pos)
        self.velocity = pygame.Vector2(random.uniform(-1, 1), random.uniform(-1, 1)) * speed
        self.lifetime = random.uniform(*lifetime_range)
        self.initial_lifetime = self.lifetime
        self.radius = random.randint(*radius_range)
        self.color = color

    def update(self, dt):
        self.lifetime -= dt
        self.pos += self.velocity * dt

    def draw(self, surface):
        if self.lifetime > 0:
            alpha = max(0, int(255 * (self.lifetime / self.initial_lifetime)))
            fade_color = (*self.color[:3], alpha)
            temp_surf = pygame.Surface((self.radius * 2, self.radius * 2), pygame.SRCALPHA)
            pygame.draw.circle(temp_surf, fade_color, (self.radius, self.radius), self.radius)
            surface.blit(temp_surf, (self.pos.x - self.radius, self.pos.y - self.radius))
