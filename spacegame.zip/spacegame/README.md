# 🚀 Spacegame — Top-Down Shooter

A high-fidelity modular top-down space shooter built with **Pygame**.  
Clean architecture, particle effects, screen shake, wave-based enemy spawns, and more.

---

## 🎮 Features

- WASD movement + mouse-aimed rotation
- Bullet shooting with direction + rotation
- Enemy tracking AI with health bars
- Flash/red feedback on hit
- Particle system (damage + death)
- Crosshair + HUD (kills, waves, record)
- Wave system with scaling difficulty
- Pause and Game Over screens
- Main menu + record saving

---

## 🧠 Controls

| Action       | Key/Mouse        |
|--------------|------------------|
| Move         | `WASD`           |
| Shoot        | `Left Click`     |
| Pause        | `ESC`            |
| Restart      | `R`              |
| Quit         | `M`              |

---

## 🗂 Directory Structure

```txt
spacegame/
├── assets/
│   ├── images/
│   └── fonts/
├── data/
│   └── record.txt
├── src/
│   ├── main.py
│   ├── settings.py
│   ├── utils.py
│   ├── player.py
│   ├── enemy.py
│   ├── bullet.py
│   ├── particle.py
│   └── ui.py
├── README.md
└── requirements.txt
