const lettersElement = document.getElementById('letters');
const wordInput = document.getElementById('wordInput');
const submitWordButton = document.getElementById('submitWord');
const scoreElement = document.getElementById('score');
const messageElement = document.getElementById('message');

let letters = '';
let score = 0;

// Function to generate random letters
function generateRandomLetters() {
  const alphabet = 'abcdefghijklmnopqrstuvwxyz';
  let randomLetters = '';
  for (let i = 0; i < 7; i++) {
    randomLetters += alphabet.charAt(Math.floor(Math.random() * alphabet.length));
  }
  return randomLetters;
}

// Function to check if the word is valid
function isValidWord(word) {
  return word.split('').every(char => letters.includes(char));
}

// Function to reset the game with new letters
function startNewRound() {
  letters = generateRandomLetters();
  lettersElement.textContent = letters.toUpperCase();
  wordInput.value = '';
  wordInput.focus();
  messageElement.textContent = '';
}

// Handle the submit button click
submitWordButton.addEventListener('click', () => {
  const word = wordInput.value.toLowerCase();

  if (word.length < 3) {
    messageElement.textContent = 'Word must be at least 3 letters!';
    return;
  }

  if (isValidWord(word)) {
    score += word.length;
    scoreElement.textContent = score;
    messageElement.textContent = 'Correct!';
  } else {
    messageElement.textContent = 'Invalid word, try again!';
  }

  wordInput.value = '';
  startNewRound();
});

// Start the first round
startNewRound();

console.log('running')

